Using prepared statement and htmlentities we can prevent sql injection and XSS attack
      