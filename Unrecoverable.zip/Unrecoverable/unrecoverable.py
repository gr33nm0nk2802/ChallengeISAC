import os,sys
import ctypes

def checkFile(path):
    return os.path.exists(path)

def deleteFile(path):
    try:
        os.remove(path)
    except Exception as e:
        print(f"[-] Error - {e}")

def randPass(file_ptr, file_size):
    try:
        file_ptr.write(os.urandom(file_size))
    except Exception as e:
        print(f"[-] Error - {e}")

def nullPass(file_ptr, file_size):
    try:
        file_ptr.write(b"\x00"*file_size)
    except Exception as e:
        print(f"[-] Error - {e}")

def onePass(file_ptr, file_size):
    try:
        file_ptr.write(b"\x01"*file_size)
    except Exception as e:
        print(f"[-] Error - {e}")


def unrecover(passes):

    if not is_admin():
        print("[+] Run the program as Administrator")
        return
    path = input("[+] Enter the path of the file to delete: ").strip()
    if checkFile(path):
        if input(f"[+] Are you sure you want to remove the file {path}? .(y/N)").lower() != 'y':
            return
        else:
            file_ptr = open(path, "wb")
            file_size = os.path.getsize(path)
            print("[+] Removing file.")
            for i in range(passes):
                print(f"[+] Pass: {i}")
                print(f"[+] Null Pass")
                nullPass(file_ptr, file_size)
                print(f"[+] One Pass")
                onePass(file_ptr, file_size)
                print(f"[+] Random Pass")
                randPass(file_ptr, file_size)
                print(f"[+] Null Pass")
                nullPass(file_ptr, file_size)
            file_ptr.close()
            deleteFile(path)
            print("[+]  Removed the file from the system")
    else:
        print("[-] File not found.")

def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

def main():
    passes=int(input("[+] Enter number of passes between 14 to 20: "))
    if passes < 14:
        print("[+] Too few pass. Default to 14 pass.")
        passes = 14
    if passes > 20:
        print("[+] Too many pass, Default to max 20 pass")
        passes = 20
    unrecover(passes)


if __name__ == "__main__":
    main()
