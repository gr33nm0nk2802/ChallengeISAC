#!/usr/bin/python3

import os
import pickle
import base64
import hashlib
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
from Crypto.Util.Padding import pad,unpad

__key__ = hashlib.sha256(b'AAAABBBBCCCCDDDD').digest()

def encrypt(raw):
    raw = base64.b64encode(pad(raw,16))
    iv = get_random_bytes(AES.block_size)
    cipher = AES.new(key= __key__, mode= AES.MODE_CFB,iv= iv)
    return base64.b64encode(iv + cipher.encrypt(raw))

def fun(name,password):
    s = {"username":name,"password":password}
    safecode = encrypt(pickle.dumps(s))
    with open("users.json","wb") as f:
        f.write(safecode)
    return safecode

if __name__ == '__main__':
    u = input("Username : ")
    p = input("Password : ")
    yo_fun = fun(u,p)
